package com.example.campus_capitalists24;

import android.content.res.AssetManager;

import androidx.activity.ComponentActivity;

import java.io.IOException;
import java.util.Scanner;

public class IncomeEntry extends ComponentActivity {

    private AssetManager assets;

    private int id;
    private String amount;
    private String date;

    public IncomeEntry(int id, String amount, String date) {
        this.id = id;
        this.amount = amount;
        this.date = date;
    }

    public IncomeEntry(int id, AssetManager assets){
        this.id = id;
        setupFromFile(id, assets);
    }

    public int getId() {
        return id;
    }

    public void setId(int Id) {
        this.id = Id;
    }

    public String getAmount() {
        return amount;
    }

    public void setAmount(String amount) {
        this.amount = amount;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    private void setupFromFile(int id, AssetManager assets){
        Scanner scan;
        String str = "";
        String [] arr;

        try{
            scan = new Scanner(this.assets.open("income_history.txt"));

            while(scan.hasNext()) {
                str = scan.nextLine();
                arr = str.split(",");
                if (Integer.parseInt(arr[0]) == id){
                    amount = arr[1];
                    date = arr[2];
                    break;
                }
            }
            scan.close();
        }
        catch(IOException e){
            System.out.println("Error: " + e.getMessage());
        }
    }
}
