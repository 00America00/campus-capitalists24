package com.example.campus_capitalists24;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.ComponentActivity;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class IncomeListView extends ComponentActivity {

    private ListView incomeList;
    private List<String> incomeEntries;

    private void onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_income, container, false);

        incomeList = view.findViewById(R.id.income_history);
        readFromFile();

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(getBaseContext(), R.layout.fragment_income, incomeEntries) {
            @NonNull
            @Override
            public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
                View itemView = convertView;
                if (itemView == null) {
                    itemView = getLayoutInflater().inflate(R.layout.fragment_income, parent, false);
                }

                // Get the current expense string
                String expenseString = getItem(position);

                // Parse the expense data from the CSV string
                String[] arr = expenseString.split(",");
                String id = arr[0];
                String amount = arr[1];
                String date = arr[2];

                TextView amountTextView = itemView.findViewById(R.id.income_userInput);
                TextView dateTextView = itemView.findViewById(R.id.income_dateInput);

                amountTextView.setText(amount);
                dateTextView.setText(date);

                return itemView;
            }
        };
        incomeList.setAdapter(adapter);
        adapter.notifyDataSetChanged();
    };


    private void readFromFile() {
        List<String> incomeEntries = new ArrayList<>();
        Scanner scan;
        String str = "";
        String[] arr;
        File f = new File(getFilesDir().getAbsolutePath() + "/income_history.txt");

        while (f.exists()) {
            try {
                scan = new Scanner(openFileInput("income_history.txt"));
                while (scan.hasNextLine()) {
                    str = scan.nextLine();
                }
                if (str != null) {
                    arr = str.split(",");
                    if (arr.length == 3) {
                        incomeEntries.add(str);
                    }
                    break;
                }
                scan.close();
            } catch (FileNotFoundException e) {
                Toast.makeText(getBaseContext(), "IOException: " + e.getMessage(), Toast.LENGTH_SHORT).show();
            }
        }
    }
}