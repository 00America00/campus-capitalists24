package com.example.campus_capitalists24;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import java.io.File;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.util.Scanner;

import androidx.activity.ComponentActivity;

import com.example.campus_capitalists24.R;

public class IncomeAddEntry extends ComponentActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.fragment_income);
        setupButtons();
    }

    private void setupButtons() {
        Button button = (Button) findViewById(R.id.income_submit);
        button.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                int id = -1;
                EditText amountInput = (EditText) findViewById(R.id.income_userInput);
                EditText dateInput = (EditText) findViewById(R.id.income_dateInput);

                if (validateEntry()) {
                    addEntry(id);
                    amountInput.setText("");
                    dateInput.setText("");

                } else {
                    amountInput.setText("");
                    dateInput.setText("");
                    amountInput.setError("All fields must be filled out.");
                    dateInput.setError("All fields must be filled out.");
                }
            }
        });
    }

    private Boolean validateEntry(){
        EditText amountInput = (EditText) findViewById(R.id.income_userInput);
        EditText dateInput = (EditText) findViewById(R.id.income_dateInput);
        if(!amountInput.getText().toString().equals("") && !dateInput.getText().toString().equals("")){
            return true;
        }
        return false;
    }

    private void addEntry(int id) {
        EditText amountInput = (EditText) findViewById(R.id.income_userInput);
        EditText dateInput = (EditText) findViewById(R.id.income_dateInput);
        String amount = amountInput.getText().toString();
        String date = dateInput.getText().toString();

        File f = new File(getFilesDir().getAbsolutePath() + "/income_history.txt");
        OutputStreamWriter w = null;
        Scanner scan;
        id = -1;
        String str = "";
        String[] arr;

        if (!f.exists()) {
            id = 1;
            try {
                w = new OutputStreamWriter(openFileOutput("income_history.txt", MODE_PRIVATE));
                w.write(id + "," + amount + "," + date);
                w.close();
            } catch (IOException e) {
                Toast.makeText(getBaseContext(), "IOException: " + e.getMessage(), Toast.LENGTH_SHORT).show();
            }
        } else {
            try {
                scan = new Scanner(openFileInput("income_history.txt"));
                while (scan.hasNextLine()) {
                    str = scan.nextLine();
                }
                if (str != null) {
                    arr = str.split(",");
                    if (arr.length == 3) {
                        id = Integer.parseInt(arr[0]) + 1;
                    }
                }
                scan.close();

                w = new OutputStreamWriter(openFileOutput("income_history.txt", MODE_APPEND));
                w.append("\n" + id + "," + amount + "," + date);
                w.close();
            } catch (IOException e) {
                Toast.makeText(getBaseContext(), "IOException: " + e.getMessage(), Toast.LENGTH_SHORT).show();
            }
        }
    }
}
